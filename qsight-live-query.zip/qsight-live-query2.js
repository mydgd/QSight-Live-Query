define(["qlik", './semantic', './transition', './fontawesome', "css!./qsight-live-query2.css", "css!./semantic.css"],
    function (qlik, template) {

        "use strict";
        return {
            template: template,
            initialProperties: {
                qHyperCubeDef: {
                    qDimensions: [],
                    qMeasures: [],
                    qInitialDataFetch: [{
                        qWidth: 2,
                        qHeight: 500
                    }]
                }
            },
            definition: {
                type: "items",
                component: "accordion",
                items: {
                    settings: {
                        uses: "settings",
                        items: {
                            MyList: {
                                type: "array",
                                ref: "listItems",
                                label: "Dimensions",
                                itemTitleRef: "dim_label",
                                allowAdd: true,
                                allowRemove: true,
                                addTranslation: "Add Dimension",
                                items: {
                                    labelHeader: {
                                        type: "string",
                                        ref: "fieldHeader",
                                        label: "Label"
                                    },
                                    label1: {
                                        type: "string",
                                        ref: "dim_label",
                                        expressionType: 'dimension',
                                        expression: 'always',
                                        label: "Source Field"

                                    },
                                    label2: {
                                        type: "string",
                                        ref: "dim_id",
                                        expressionType: 'dimension',
                                        expression: 'always',
                                        label: "Source Field Key"
                                    },
                                    label3: {
                                        type: "string",
                                        ref: "fact_id",
                                        label: "Target Field Key (Optional - Only required if different than the source field)"
                                    },

                                    radio1: {
                                        type: "string",
                                        component: "radiobuttons",
                                        label: "Field Data Type",
                                        ref: "fieldDataType",
                                        options: [{
                                            value: "i",
                                            label: "Integer"
                                        }, {
                                            value: "s",
                                            label: "String"
                                        }],
                                        defaultValue: "i"
                                    },

                                    radio2: {
                                        type: "string",
                                        component: "radiobuttons",
                                        label: "Selection Type",
                                        ref: "fieldSelectionType",
                                        options: [{
                                            value: "m",
                                            label: "Multiple"
                                        }, {
                                            value: "s",
                                            label: "Single"
                                        }],
                                        defaultValue: "m"
                                    },

                                    //Only active when Selection Type is Single
                                    radio4: {
                                        type: "string",
                                        component: "dropdown",
                                        label: "Comparison Operator",
                                        ref: "fieldComparisonOperator",
                                        options: function (data) {
                                            if (data.fieldSelectionType == 's') {
                                                return [{
                                                    value: "=",
                                                    label: "=   Equal to"
                                                }, {
                                                    value: ">",
                                                    label: ">   Greater than"
                                                },
                                                {
                                                    value: "<",
                                                    label: "<   Less than"
                                                },
                                                {
                                                    value: ">=",
                                                    label: ">=  Greater than or equal to"
                                                },
                                                {
                                                    value: "<=",
                                                    label: "<=  Less than or equal to"
                                                },
                                                {
                                                    value: "<>",
                                                    label: "<>  Not equal to"
                                                }]
                                            }
                                            else {
                                                return [{
                                                    value: "=",
                                                    label: "=   Equal to"
                                                }]
                                            }
                                        }
                                        ,
                                        defaultValue: "="
                                    },

                                    radio3: {
                                        type: "string",
                                        component: "radiobuttons",
                                        label: "Mandatory Selection",
                                        ref: "fieldMandatoryOptional",
                                        options: [{
                                            value: "m",
                                            label: "Mandatory"
                                        }, {
                                            value: "o",
                                            label: "Optional"
                                        }],
                                        defaultValue: "o"
                                    }

                                }
                            },
                            // Definition of the custom section header
                            generalSettings: {
                                type: "items",
                                label: "General Setting",
                                items: {

                                    radioDataSource: {
                                        type: "string",
                                        component: "radiobuttons",
                                        label: "Datasource Type",
                                        ref: "fieldDatasourceType",
                                        options: [{
                                            value: "d",
                                            label: "Database"
                                        }, {
                                            value: "q",
                                            label: "QVD"
                                        }],
                                        defaultValue: "d"
                                    },

                                    radioSaveData: {
                                        type: "boolean",
                                        component: "radiobuttons",
                                        label: "Save Application After Refresh",
                                        ref: "radioSaveData",
                                        options: [{
                                            value: true,
                                            label: "Save"
                                        }, {
                                            value: false,
                                            label: "Do not save"
                                        }],
                                        defaultValue: false
                                    },
                                    textSaveData: {
                                        label: "If you set this property to 'Save', previous data refresh of other users will be overwritten. Don't use 'Save' unless required.",
                                        component: "text"
                                    },


                                    variableName: {
                                        ref: "variableName",
                                        label: "Select a variable for where statement",
                                        type: "string",
                                        component: "dropdown",
                                        options: function () {
                                            return qlik.currApp().createGenericObject({
                                                qVariableListDef: {
                                                    qType: "variable"
                                                }
                                            }).then(function (e) {
                                                return e.layout.qVariableList.qItems.map(function (e) {
                                                    return {
                                                        value: e.qName,
                                                        label: e.qName.length > 50 ? e.qName.slice(0, 50) + "..." : e.qName
                                                    }
                                                })
                                            })
                                        },
                                        change: function (e) {
                                            e.variableValue = e.variableValue || {}, e.variableValue.qStringExpression = '="' + e.variableName + '"'
                                        }
                                    },
                                    radioInfo: {
                                        type: "boolean",
                                        component: "switch",
                                        label: "Show information",
                                        ref: "radioInfo",
                                        options: [{
                                            value: true,
                                            label: "Show"
                                        }, {
                                            value: false,
                                            label: "Hide"
                                        }],
                                        defaultValue: false
                                    },
                                }
                            },
                            about: {
                                type: "items",
                                label: "About",
                                items: {
                                    aboutText1: {
                                        label: "QSight Live Query Extension by Mustafa Aydogdu.",
                                        component: "text"
                                    },

                                    aboutText2: {
                                        label: "Please check Github for latest version and documentation.",
                                        component: "text"
                                    },
                                    aboutLink: {
                                        label: "Github",
                                        component: "link",
                                        url: "https://github.com/mydgd"
                                    }
                                }
                            }
                        }
                    }
                }
            },
            support: {
                snapshot: true,
                export: true,
                exportData: true
            },
            paint: function ($element, layout) {

                this.layoutString = this.prevLayout = JSON.stringify(layout.listItems) + layout.variableName + layout.radioSaveData + layout.radioInfo + layout.fieldDatasourceType;

                //Repaint if the settings of extension has changed
                if (this.prevLayoutString != this.layoutString) {
                    this.painted = false;
                }

                if (this.painted) return;

                this.painted = true;

                this.prevLayoutString = this.layoutString;

                $element.empty();

                var app = qlik.currApp(this);
                var app_id = app.id;
                var whereStatement = '';
                var qvdWhereStatement = '';

                //var $container = $( "<div id='container'></div>" );
                var html = '';

                var $container = '<div id="container" style="overflow-y: auto;height: 100%; "</div>';

                $element.append($container);

                //Append reload button message-warning

                $("#container").append('<button id="refreshButton" class= "myButton myButton__text"><i class="fas fa-redo-alt"></i> Reload</button>');
                $("#container").append('<button id="clearButton" class= "myButton-blue myButton__text"><i class="fas fa-trash-alt"></i> Clear</button>');
                $("#container").append('<div id="errorDiv" class="message-error"> </div>');
                $("#container").append('<div id="warningDiv" class="message-warning"> </div>');
                $("#container").append('<div id="infoDiv" class="message-info"> </div>');
                $("#container").append('<form id="form" "></form>');

                $('#errorDiv').hide();
                $('#warningDiv').hide();
                $('#infoDiv').hide();


                //$('#container').append("<button id='refreshButton' type='' class= 'myButton myButton__text'>Run Live Query</button>");

                //console.log(container);

                layout.listItems.forEach(function (item, index, array) {
                    //console.log(array);

                    var sourceFieldName = item.dim_label.trim();
                    var sourceFieldNameNoSpace = sourceFieldName.substring(1).replace(/\s/g, '');
                    sourceFieldNameNoSpace = sourceFieldNameNoSpace.replace("]", "");
                    sourceFieldNameNoSpace = sourceFieldNameNoSpace.replace("[", "");
                    var sourceFieldKey = item.dim_id.trim();
                    var fieldDataType = item.fieldDataType;
                    var fieldSelectionType = item.fieldSelectionType;


                    //Create div for each dimension
                    $("#form").append('<div id="div_' + sourceFieldNameNoSpace + '"> </div>');

                    app.createCube({
                        "qInitialDataFetch": [{
                            "qHeight": 1000,
                            "qWidth": 2
                        }],
                        "qDimensions": [{
                            "qDef": {
                                "qFieldDefs": [
                                    sourceFieldName
                                ]
                            },
                            "qNullSuppression": true,
                            "qOtherTotalSpec": {
                                "qOtherMode": "OTHER_OFF",
                                "qSuppressOther": true,
                                "qOtherSortMode": "OTHER_SORT_DESCENDING",
                                "qOtherCounted": {
                                    "qv": "5"
                                },
                                "qOtherLimitMode": "OTHER_GE_LIMIT"
                            }
                        },
                        {
                            "qDef": {
                                "qFieldDefs": [
                                    sourceFieldKey
                                ]
                            },
                            "qNullSuppression": true,
                            "qOtherTotalSpec": {
                                "qOtherMode": "OTHER_OFF",
                                "qSuppressOther": true,
                                "qOtherSortMode": "OTHER_SORT_DESCENDING",
                                "qOtherCounted": {
                                    "qv": "5"
                                },
                                "qOtherLimitMode": "OTHER_GE_LIMIT"
                            }
                        }
                        ],
                        "qMeasures": [],
                        "qSuppressZero": false,
                        "qSuppressMissing": false,
                        "qMode": "S",
                        "qInterColumnSortOrder": [],
                        "qStateName": "$"
                    }, function (reply, app) {

                        sourceFieldName = sourceFieldName.substring(1);
                        sourceFieldName = sourceFieldName.replace("[", "");
                        sourceFieldName = sourceFieldName.replace("]", "");
                        var sourceFieldNameNoSpace = sourceFieldName.replace(/\s/g, '');
                        var fieldMandatoryOptional = item.fieldMandatoryOptional;

                        var valueList = reply.qHyperCube.qDataPages[0].qMatrix;

                        var fieldHeader = item.fieldHeader;

                        if (typeof (fieldHeader) == 'undefined') {
                            fieldHeader = sourceFieldName;
                        }


                        var divId = '#div_' + sourceFieldNameNoSpace;

                        if (fieldMandatoryOptional == 'm') {
                            sourceFieldName += ' *';
                        }
                        //Set label for dropdown
                        html = '<p style="margin-top:10px;"></p> <label style="font: bold 16px \'Source Sans Pro\', san-serif; ">' + fieldHeader + '</label>';

                        if (fieldSelectionType == 'm') {//Multiple selection allowed
                            html += '<div id="list_' + sourceFieldNameNoSpace + '" ><select style="min-width:100%;" multiple="" class="ui filters search selection dropdown multiple required">'
                        }
                        else {//only single selection 
                            html += '<div id="list_' + sourceFieldNameNoSpace + '" ><select class="ui filters dropdown">'
                        }

                        //Set values for dropdown
                        valueList.forEach((element) => {
                            html += '<option class="item" value="' + element[1].qText + '">' + element[0].qText + '</option>';
                        })

                        html += '</select></div>'

                        $(divId).append(html);

                        app.destroySessionObject(reply.qInfo.qId);
                        //$element.html('<div style="width:200px;"><select><option value="EMP1">Rock Roll</option> </select></div>');

                        //$element.html(html);

                        //$element.append(container);

                        $('.filters.ui.dropdown')
                            .dropdown({
                                allowAdditions: true
                            });

                        $('#clearButton').click(function () {
                            $('.filters.ui.dropdown').dropdown('restore defaults');
                            $('#errorDiv').hide();
                            $('#warningDiv').hide();
                            $('#infoDiv').hide();
                        }
                        );

                        document.getElementById("refreshButton").addEventListener("click", callRunQuery);


                        //$('#form').attr('action', callRunQuery);
                    }); //End of create hypercube

                }); //end of list foreach

                function isInteger(value) {
                    return /^\d+$/.test(value);
                }

                function callRunQuery() {

                    var whereStatement = '';
                    var qvdWhereStatement = '';
                    var startTime = new Date();
                    var radioSaveData = layout.radioSaveData;
                    var variableName = layout.variableName;
                    var mandatorySelectionCheck = true;
                    $('#errorDiv').empty();
                    $('#infoDiv').empty();
                    $('#warningDiv').empty();
                    $('#warningDiv').hide();
                    $('#errorDiv').hide();
                    $('#infoDiv').hide();

                    if (variableName == '') {
                        $('#errorDiv').show();
                        $('#errorDiv').append(' <p class="message"><i class="fas fa-exclamation-triangle"></i> Please select a variable in general settings of the extension</p>');
                        return false;
                    }
                    //Loop dimensions and create where statement for selected dimensions
                    layout.listItems.forEach(function (item, index, array) {


                        var sourceFieldName = item.dim_label.substring(1);
                        sourceFieldName = sourceFieldName.replace("[", "");
                        sourceFieldName = sourceFieldName.replace("]", "");
                        var sourceFieldNameNoSpace = sourceFieldName.replace(/\s/g, '');
                        var elementSelected = '#list_' + sourceFieldNameNoSpace + ' :selected';
                        var fieldDataType = item.fieldDataType;
                        var fieldMandatoryOptional = item.fieldMandatoryOptional;
                        var fieldComparisonOperator = item.fieldComparisonOperator;
                        var fieldSelectionType = item.fieldSelectionType;
                        var fieldHeader = item.fieldHeader;
                        var targetFieldKey = item.fact_id.trim();
                        var selectedCount = $(elementSelected).length;

                        if (fieldHeader == '') {
                            fieldHeader = sourceFieldName;
                        }

                        if (targetFieldKey == '') {//if blank use source field key name
                            targetFieldKey = item.dim_id.substring(1);
                        }

                        if (selectedCount == 0 && fieldMandatoryOptional == 'm') {
                            mandatorySelectionCheck = false;
                            $('#errorDiv').show();
                            $('#errorDiv').append(' <p class="message"><i class="fas fa-exclamation-triangle"></i> Please make a selection for <b>' + fieldHeader + ' </b></p>');
                        }

                        if (selectedCount > 0) { //if there are selections for current dimension

                            if (whereStatement.length > 0) {
                                whereStatement += ' AND ';
                                qvdWhereStatement += ' AND ';
                            } else {
                                whereStatement += 'WHERE ';
                                qvdWhereStatement += 'WHERE ';
                            }

                            whereStatement += targetFieldKey;

                            if (selectedCount == 1) { //if there is only one selection

                                qvdWhereStatement += targetFieldKey;

                                $(elementSelected).each(function () {

                                    //Check if field is string but declared integer in the settings
                                    if (isInteger(this.value) == false && fieldDataType == 'i') {
                                        $('#warningDiv').show();
                                        $('#warningDiv').append(' <p class="message"><i class="fas fa-exclamation-triangle"></i><b>' + fieldHeader + ' </b>includes non-integer values. Please consider changing data type to string in the extension settings.</p>');
                                    }

                                    var filterItem = '';
                                    if (fieldDataType == 's') {
                                        filterItem = '\'' + this.value + '\'';


                                    }
                                    else {
                                        filterItem = this.value;
                                    }

                                    if (fieldSelectionType == 's') {
                                        whereStatement += fieldComparisonOperator + filterItem;
                                        qvdWhereStatement += fieldComparisonOperator + filterItem;
                                    } else {
                                        whereStatement += '=' + filterItem;
                                        qvdWhereStatement += '=' + filterItem;
                                    }

                                });
                            } //end if single selection
                            if (selectedCount > 1) { //if multiple selection
                                qvdWhereStatement += 'MATCH(' + targetFieldKey + ',';
                                whereStatement += ' IN (';
                                var nonIntegerCount = 0;

                                $(elementSelected).each(function (index) {
                                    var filterItem = '';

                                    //Check if field is string but declared integer in the settings
                                    if (isInteger(this.value) == false && fieldDataType == 'i') {
                                        nonIntegerCount++;
                                        console.log(nonIntegerCount);
                                    }

                                    if (fieldDataType == 's') {
                                        filterItem = '\'' + this.value + '\'';
                                    }
                                    else {
                                        filterItem = this.value;
                                    }

                                    if (index > 0) {
                                        whereStatement += ', ' + filterItem;
                                        qvdWhereStatement += ', ' + filterItem;
                                    } else {
                                        whereStatement += filterItem;
                                        qvdWhereStatement += filterItem;
                                    }
                                });

                                //if there non integer values in integer field then show warning
                                if (nonIntegerCount > 0) {
                                    $('#warningDiv').show();
                                    $('#warningDiv').append(' <p class="message"><i class="fas fa-exclamation-triangle"></i><b>' + fieldHeader + ' </b>includes non-integer values. Please consider changing data type to string in the extension settings.</p>');
                                }
                                whereStatement += ') ';
                                qvdWhereStatement += ') ';
                            } //end if multiple selection	
                        } //end if there are selections for current dimension									

                    });//end of loop each dimension 

                    if (mandatorySelectionCheck) {//If there is any mandatory selection and they are selected then continue
                        //console.log('whereStatement: 1' + whereStatement);
                        document.getElementById("refreshButton").disabled = true;
                        document.getElementById("refreshButton").classList.add("myButton--loading");
                        console.log(qvdWhereStatement);
                        if (layout.fieldDatasourceType == 'q') {
                            whereStatement = qvdWhereStatement;
                        }

                        if (layout.radioInfo) {
                            $('#infoDiv').show();
                            $('#infoDiv').append('<p class="message"><b> Filter: </b>' + whereStatement + '</p>');
                            $('#infoDiv').append('<p class="message"><b> Selected Variable: </b>' + variableName + '</p>');
                            $('#infoDiv').append('<p class="message"><b> Start Time: </b>' + startTime.toLocaleString() + '</p>');
                        }


                        app.variable.setStringValue(variableName, whereStatement).then(function () {

                            setTimeout(function () {
                                app.doReload(0, true, false).then(function (e) {
                                    //clearTimeout(timer);

                                    // setTimeout(function () {
                                    document.getElementById("refreshButton").disabled = false;
                                    document.getElementById("refreshButton").classList.remove("myButton--loading");
                                    //}
                                    //  , 300);

                                    var finishTime = new Date();
                                    var queryDuration = new Date(null);
                                    queryDuration.setSeconds((finishTime.getTime() - startTime.getTime()) / 1000);

                                    $('#infoDiv').append('<p class="message"><b> Finish Time: </b>' + finishTime.toLocaleString() + '</p>');
                                    $('#infoDiv').append('<p class="message"><b> Duration: </b>' + queryDuration.toISOString().substr(11, 8) + '</p>');


                                    if (e) {

                                        if (radioSaveData) {//Save application if property set to Save by user
                                            app.doSave();
                                        }
                                    } else {
                                        $('#errorDiv').append('<p><i class="fas fa-exclamation-triangle"></i> An error occured! Data has not been loaded.</p>');
                                    }

                                })
                            }, 1500);

                        });

                    }
                }; // end of callRunQuery

                //needed for export
                return qlik.Promise.resolve();
            },

        };

    });